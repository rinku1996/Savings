﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using RBA_Entities;
using RBA_Exception;
namespace RBA_DAL
{
    public class ProductDal
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static ProductDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public ProductDal()
        {
            con = new SqlConnection(conStr);
        }
        public DataTable DisplayProductDal()
        {
            DataTable dt = null;


            try
            {

                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "DisplayProduct_172303";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        public int AddProductDal(Product product)
        {
            int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "InsertProduct_172303_1";//  stored proceduresssss
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@productId", SqlDbType.Int);
                cmd.Parameters["@productId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                cmd.Parameters.AddWithValue("@Description", product.Description);
                cmd.Parameters.AddWithValue("@Price", product.UnitPrice);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                
                pid = int.Parse(cmd.Parameters["@productId"].Value.ToString());
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
    }
}
