﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Customer_Entity;
using Customer_Exception;



namespace Customer_DAL
{
    public class CustomerOperations
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pboj"></param>
        /// <returns></returns>
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        //using static constructor to load connection string
        static CustomerOperations()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        //creating a object for the opened connection
        public CustomerOperations()
        {
            con = new SqlConnection(conStr);
        }
        //method for displaying customer
        public DataTable DisplayCustomer_DAL()
        {
            DataTable dt = null;

            try
            {
                cmd = new SqlCommand("disp_CustomerDetails_309", con);//stored procedure for displaying customers
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        //method for adding customer
        public int AddCustomer_DAL(Customer seobj)
        {
            int cid = 0;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "udpAddCustomer_309";//stored procedure for adding customer
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@customerID", SqlDbType.Int);
                cmd.Parameters["@customerID"].Direction = ParameterDirection.Output;//getting the auto incremented id from db

                cmd.Parameters.AddWithValue("@customerName", seobj.CustomerName);
                cmd.Parameters.AddWithValue("@city", seobj.City);
                cmd.Parameters.AddWithValue("@country", seobj.Country);
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                cid = int.Parse(cmd.Parameters["@customerID"].Value.ToString());
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return cid;//returning the id to display in the form
        }
    }
}
