﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Customer_Entity;
using Customer_Exception;
using Customer_DAL;


namespace Customer_BAL
{
    public class CustomerValidations
    {
        private bool ValidateCustomer(Customer newCustomer)
        {
            bool isValidCustomer = true;
            StringBuilder sbClientError = new StringBuilder();
            if (newCustomer.CustomerName.Equals(string.Empty))//validation for blank name
            {
                isValidCustomer = false;
                sbClientError.Append("Who the hell has name blank!!:)" + Environment.NewLine);
            }
            //validation for blank city name
            if (newCustomer.City.Equals(string.Empty))
            {
                isValidCustomer = false;
                sbClientError.Append("City is  blank!!:)" + Environment.NewLine);
            }
            //validation for blank country
            if (newCustomer.Country.Equals(string.Empty))
            {
                isValidCustomer = false;
                sbClientError.Append("Country is  blank!!:)" + Environment.NewLine);
            }
            if (!isValidCustomer)
            {
                throw new CustomerException(sbClientError.ToString());
            }
            return isValidCustomer;
        }
        public DataTable DisplayCustomer_BLL()
        {
            try
            {
                CustomerOperations co = new CustomerOperations();
                return co.DisplayCustomer_DAL();//using display mehtod from DAL
            }
            catch (CustomerException c)//catching custom exception
            {
                throw c;
            }
            catch (SqlException se)//catching sql exception
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public int AddCustomer_BLL(Customer seobj)
        {
            int cid = 0;
            try
            {
                CustomerOperations co = new CustomerOperations();
                if (ValidateCustomer(seobj))
                {
                    cid = co.AddCustomer_DAL(seobj);//using add method from DAl
                }
                else throw new CustomerException("Failed to Add Customer");
                return cid;
            }
            catch (CustomerException c)
            {
                throw c;
            }
            catch (SqlException pe)
            {
                throw pe;
            }
            catch (Exception pe)
            {
                throw pe;
            }
        }
    }
}
