﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Customer_BAL;
using Customer_Entity;
using Customer_Exception;
using System.Data;

namespace Customer_PL
{
    /// <summary>
    /// Interaction logic for Display.xaml
    /// </summary>
    public partial class Display : Window
    {
        public Display()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                CustomerValidations cv = new CustomerValidations();
                DataTable dt = cv.DisplayCustomer_BLL();
                if (dt != null)
                {
                    dgCustomer.ItemsSource = dt.DefaultView;
                }
                else
                {
                    MessageBox.Show("Table is empty", "Customer Information System");
                }
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message, "Customer Information System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Customer Information System");
            }
        }
    }
    
}
