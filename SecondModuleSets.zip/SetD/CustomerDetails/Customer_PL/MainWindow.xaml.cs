﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Customer_BAL;
using Customer_Entity;
using Customer_Exception;
using System.Data.SqlClient;
using System.Configuration;

namespace Customer_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        static string conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        SqlConnection con = new SqlConnection(conStr);
        SqlCommand cmd = null;

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Customer c = new Customer
                {
                    CustomerName = txtName.Text,
                    City = cbCity.Text,
                    Country = cbCountry.Text
                };

                CustomerValidations cv = new CustomerValidations();
                int cid = cv.AddCustomer_BLL(c);
                MessageBox.Show(string.Format("New Custmer Added.\nCustomer Id: {0}", cid), "Customer Information System");
                MainWindow mainWindow = new MainWindow();       //creating a object for main window
                mainWindow.Show();                          //showing the new Main Window so we can add next customer and the previous customer details cannot be seen
                Close();                                     //closing the present window
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message, "Customer Information System");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Customer Information System");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Customer Information System");
            }

        }

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            Display newWindow = new Display();
            newWindow.Show();//This will take the control to Display Window

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            con.ConnectionString = conStr;
            //executing cmd for auto incremented ID
            cmd = new SqlCommand("select ident_current('CustomerDetails_309') + ident_incr('CustomerDetails_309')", con);
            try
            {
                con.Open();
                object nxId = cmd.ExecuteScalar();   //storing the auto incremented ID 
                txtId.Text = nxId.ToString();            //displaying it in text box

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
