﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS_Entity
{
    public class CustomerEntity
    {
        public int Cust_Id { get; set; }
        public string Cust_Name { get; set; }
        public string Cust_City { get; set; }
        public string Cust_Country { get; set; }
    }
}
