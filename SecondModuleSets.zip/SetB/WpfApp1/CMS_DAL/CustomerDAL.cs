﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CMS_Entity;
using CMS_Exception;
namespace CMS_DAL
{
    public class CustomerDAL
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static CustomerDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public CustomerDAL()
        {

            con = new SqlConnection(conStr);
        }
        /// <summary>
        /// Addcustomer method for adding Customer Details
        /// </summary>
        /// <param name="cust"></param>
        public void AddCustomer(CustomerEntity cust)
        {


            try
            {
                //Connection with SqlDataBase using Connected Architecture 
                cmd = new SqlCommand();
                cmd.CommandText = "Ins_AddCustomer_172303";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@CusId", SqlDbType.Int);
                cmd.Parameters["@CusId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@CustName", cust.Cust_Name);
                cmd.Parameters.AddWithValue("@CustCity", cust.Cust_City);
                cmd.Parameters.AddWithValue("@CustCountry", cust.Cust_Country);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

            }

            catch (CustomerException ex) { throw ex; }
            catch (SqlException ex1)
            {
                throw ex1;
            }
            catch (SystemException ex2)
            {
                throw ex2;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public DataTable Display()
        {
            DataTable dt = null;

            try
            {
                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "DisplayProd_172303";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (CustomerException ex) { throw ex; }
            catch (SqlException ex1)
            {
                throw ex1;
            }
            catch (SystemException ex2)
            {
                throw ex2;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }

        /// <summary>
        /// Automatic number for ID
        /// </summary>
        /// <returns></returns>
        DataTable dtStudent = new DataTable();
        public int AutoMat()
        {
            int p = 0;
            try
            {

                cmd = new SqlCommand("select IDENT_CURRENT('CustomerManagment_172303')", con);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dtStudent.Load(dr);
                    p = int.Parse(dtStudent.Rows[0][0].ToString());
                }
            }
            catch (CustomerException ex) { throw ex; }
            catch (SqlException ex1)
            {
                throw ex1;
            }
            catch (SystemException ex2)
            {
                throw ex2;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return p + 1;
        }


    }
}

