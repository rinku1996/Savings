﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Data.SqlClient;
using PMS_ENTITY;
using PMS_BLL;
using PMS_EXCEPTION;

namespace PMS_PL
{
    /// <summary>
    /// Interaction logic for AddPatient.xaml
    /// </summary>
    public partial class AddPatient : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        SqlCommand SqlCommand;

        public AddPatient()
        {
            InitializeComponent();
        }

        private void btn_AddPatient_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                string GE = " ";


                if (rbtn_Male.IsChecked == true)
                    GE = rbtn_Male.Content.ToString();

                else if (rbtn_Female.IsChecked == true)
                    GE = rbtn_Female.Content.ToString();

                DateTime date1 = new DateTime();
                date1 = DateTime.Now;

                Patient p = new Patient
                {
                    LoginTime = DateTime.Parse(tb_Login.Text),
                    PatientId = int.Parse(tb_ID.Text),
                    FistName = txt_FirstName.Text,
                    LastName = txt_LastName.Text,
                    Gender = GE.ToString(),//char.Parse(GE),//convert.ToString(GE)//
                    Address = txt_Address.Text,
                    City = txt_City.Text,
                    State = txt_State.Text,
                    PinCode = txt_PinCode.Text,
                    PhoneNumber = long.Parse(txt_Phone.Text)


                };
                PatientBLL pb = new PatientBLL();
                pb.AddPatientBLL(p);
                MessageBox.Show(string.Format("New Patient Added", "Patient Management System"));
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message, "Patient Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Patient Management System");
            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection.ConnectionString = ConnectionString;
            SqlCommand = new SqlCommand("select ident_current('PMS_172541') + ident_incr('PMS_172541')", SqlConnection);
            try
            {
                DateTime date1 = new DateTime();
                date1 = DateTime.Now;
                tb_Login.Text = date1.ToString();
                SqlConnection.Open();
                object nxId = SqlCommand.ExecuteScalar();
                //int nxtId = Convert.ToInt32(nxId);
                tb_ID.Text = nxId.ToString();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlConnection.Close();
            }

        }

        private void btn_Display_Click(object sender, RoutedEventArgs e)
        {
            Display_Patients display = new Display_Patients();
            display.Show();
        }
    }
}
