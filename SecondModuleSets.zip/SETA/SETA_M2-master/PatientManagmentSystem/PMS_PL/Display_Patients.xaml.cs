﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PMS_BLL;
using PMS_EXCEPTION;
using PMS_ENTITY;
using System.Data.SqlClient;

namespace PMS_PL
{
    /// <summary>
    /// Interaction logic for Display_Patients.xaml
    /// </summary>
    public partial class Display_Patients : Window
    {
        public Display_Patients()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                PatientBLL st = new PatientBLL();
                DataTable dt = st.DisplayPatientBLL();
                dg_Display.ItemsSource = dt.DefaultView;


            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message, "Patient Management System");
            }
            catch (SqlException se)
            {

                MessageBox.Show(se.Message.ToString());
            }
            finally
            {

            }
        }
    }
}
