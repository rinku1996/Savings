﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SearchProduct
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        Training_23Jan19_MumbaiEntities contextObj = new Training_23Jan19_MumbaiEntities();
        //creating context object

        Product1_172303_172 product = new Product1_172303_172();
        //Twice change the box so that I get the answer
        //Twice change the box so that I get the answer
        //Twice change the box so that I get the answer
        //Twice change the box so that I get the answer
        //Twice change the box so that I get the answer




        //if you change the mobile to camera you get mobile details
        //if you change the camera to Appliances you get Appliances details
        //if you change the mobile to camera you get mobile details
        //if you change the mobile to camera you get mobile details
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                
                string Brand = txt_box.Text;

                var query = from Product1_172303_172 p in contextObj.Product1_172303_172
                            where p.BrandName == Brand
                            select p;
                if (query.Count() > 0)
                {
                    dt_Display.ItemsSource = query.ToList<Product1_172303_172>();
                }

                else
                {
                    MessageBox.Show("NO Records");
                }
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Patient Management System");
            }
        }


        }
    }
}

