create table Product1_172303_172
(
SerialNumber varchar(20) not null primary key,
ProductName varchar(30)  not null,
BrandName varchar(30)  not null,
ProductType  varchar(30)  not null,
ProductDescription  varchar(30)  not null,
Price money not null

)


CREATE proc DisplayProduct_172303_1
as
begin
select * from Product1_172303_172
end
CREATE PROCEDURE InsertProduct_172303_172
	(
@SerialNumber varchar(20) ,
@ProductName varchar(30)  ,
@BrandName varchar(30),
@ProductType  varchar(30)  ,
@ProductDescription  varchar(30)  ,
@Price money 
)

AS

	insert into Product1_172303_172
	values(@SerialNumber,@ProductName,@BrandName,@ProductType,@ProductDescription ,@Price)
	RETURN 0