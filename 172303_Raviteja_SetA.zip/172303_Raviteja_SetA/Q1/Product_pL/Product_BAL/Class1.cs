﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product_Entity;
using Product_Exception;
using Product_DAL;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;
namespace Product_BAL
{
    public class Class1
    {
        StringBuilder sb = new StringBuilder();
        private bool ValidateProduct(product prod)
        {


            bool IsValidProduct = true;

            if (!Regex.Match(prod.BrandName, @"^[A-Z][a-z]*$").Success)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "Product Name should contain Characters and must begin with a capital letter!");
            }
            if (!(Regex.IsMatch(prod.SerialNumber.ToString(), @"^[0-9]{4}-[0-9]{4}-[0-9]{4}$")))
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "Product SerialNUmber must contain digits only and between 4 digits u must enter slash");
            }
            if (prod.SerialNumber.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("Product SerialNUmber cannot be blank " + Environment.NewLine);

            }
            if (prod.BrandName.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("Product BrandName cannot be blank " + Environment.NewLine);

            }
            if (prod.ProductType.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("Product Product Type cannot be blank " + Environment.NewLine);

            }
            if (prod.ProductDescription.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("Product Description cannot be blank " + Environment.NewLine);

            }
            if (prod.Price.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("Product Price cannot be blank " + Environment.NewLine);

            }
          
            if(prod.Price==0)
            {
                IsValidProduct = false;
                sb.Append("Product price must greater than zero " + Environment.NewLine);

            }
            return IsValidProduct;
        }
        public DataTable DisplayProductBal()
        {
            try
            {
                ProdDal sd = new ProdDal();
                DataTable dtProduct = sd.DisplayProductDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new ProductException("No Student Available");
                }
                return dtProduct;
            }
            catch (ProductException se)
            { throw se; }
            catch (SqlException ex)
            { throw ex; }
            catch (Exception e)
            { throw e; }
        }
        public int AddProductBAL(product product)
        {
            try
            {
                int pid = 0;
                ProdDal pd = new ProdDal();
                if (ValidateProduct(product))
                {
                    pid = pd.AddProductDal(product);
                }
                else
                    throw new ProductException(sb.ToString());

                return pid;
            }
            catch (ProductException)
            {
                throw;
            }
        }
    }
}
