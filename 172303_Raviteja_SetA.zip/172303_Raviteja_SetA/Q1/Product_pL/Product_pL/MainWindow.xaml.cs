﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using Product_BAL;
using Product_Entity;
using Product_Exception;
using System.Data;
using System.Data.SqlClient;

namespace Product_pL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection connection = new SqlConnection(connStr);
        SqlCommand command;
        DataTable dtStudent = new DataTable();
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {

                Display();

            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "employee Management System");
            }
            catch (SqlException se)
            {

                MessageBox.Show(se.Message.ToString());
            }
            finally
            {
  
            }
        }
        public void Display()
        {
            Class1 st = new Class1();
            DataTable dt = st.DisplayProductBal();
            dt_Display.ItemsSource = dt.DefaultView;


        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                product Product = new product();

                Product.ProductName = txt_Name.Text;

                Product.SerialNumber = txt_Serial.Text;
                Product.BrandName = txt_BrandName.Text;
                Product.ProductDescription = txt_ProductDiscription.Text;
                //if (txt_Type.Text == "Mobiles")
                //{
                //    Product.ProductType = "Mobiles";
                //}
                //else if (txt_Type.Text == "Camera")
                //{
                //    Product.ProductType = "Camera";

                //}
                //else if (txt_Type.Text == "Laptop")
                //{
                //    Product.ProductType = "Laptop";

                //}
                //else if (txt_Type.Text == "Appliances")
                //{
                //    Product.ProductType = "Appliances";

                //}
                //else if (txt_Type.Text == "Accesories")
                //{
                //    Product.ProductType = "Accesories";

                //}
                Product.ProductType = txt_Type.Text;
                Product.Price = double.Parse(txt_Price.Text);


                Class1 pb = new Class1();
                int pid = pb.AddProductBAL(Product);
                MessageBox.Show(string.Format("New Product Added "),
                    "Product Management System");
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            finally {
                Display();

            }
        }
    }
}
