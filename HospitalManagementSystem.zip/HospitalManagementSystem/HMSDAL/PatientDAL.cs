﻿using HMSEntity;
using HMSException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSDAL
{
    public class PatientDAL
    {
        static string ConnectionString = GlobalData.ConnectionString;        
        SqlConnection connection = new SqlConnection();

        public bool AddPatientDAL(Patient newPatient)
        {
            bool isPatientAdded=false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "spAddPatient";
                Command.Parameters.AddWithValue("@PatientId", newPatient.PatientID);
                Command.Parameters.AddWithValue("@PatientName", newPatient.PatientName);
                Command.Parameters.AddWithValue("@PhoneNumber", newPatient.Phone);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    isPatientAdded = true;
            }
            catch (PatientException)
            {
                throw;
            }
            return isPatientAdded;
        }

        //public List<Patient> GetAllPatientsDAL()
        //{

        //}

        //public bool DeletePatientDAL(int deletepatientID)
        //{

        //}


        public Patient SearchPatientDAL(int searchPatientID)
        {
            Patient SearchedPatient =new Patient();
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "spSearchPatient";
                Command.Parameters.AddWithValue("@PatientId", searchPatientID);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = Command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        SearchedPatient.PatientID = int.Parse(Reader[0].ToString());
                        SearchedPatient.PatientName = Reader[1].ToString();
                        SearchedPatient.Phone = Reader[2].ToString();
                    }
                }
            }
            catch (PatientException)
            {
                throw;
            }
            return SearchedPatient;
        }

            //public bool UpdatePatientDAL(Patient updatePatient)
            //{
            //}


        }
}
